'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'

const NAV_LINKS = [
  { name: 'About Us', href: '#about' },
  { name: 'Services', href: '#services' },
  { name: 'Projects', href: '#projects' },
  { name: 'Contact', href: '#contact' }
]

export function Navbar() {
  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 100, damping: 20 }}
      className="fixed top-0 left-0 w-full z-[100] bg-[#0A0E1A]/70 backdrop-blur-md border-b border-white/10"
    >
      <div className="max-w-7xl mx-auto px-6 py-2 flex justify-between items-center">
        {/* Left Column: Logo & Agency Name */}
        <Link href="/" className="relative flex items-center gap-3">
          <Image 
            src="/logo.png" 
            alt="WebDev Solutions Logo" 
            width={40} 
            height={40} 
            className="h-8 w-auto object-contain"
            priority
          />
          <span className="text-lg font-bold text-white tracking-wide">WebDev Solutions</span>
        </Link>

        {/* Center Column: Anchor Links */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map((link) => (
            <motion.a
              key={link.name}
              href={link.href}
              whileHover={{ textShadow: "0px 0px 8px rgba(34, 211, 238, 0.8)" }}
              className="text-sm text-[#C9CDD6] hover:text-white transition-colors relative group"
            >
              {link.name}
              <motion.div 
                className="absolute -bottom-1 left-0 w-0 h-[2px] bg-brand-cyan transition-all duration-300 group-hover:w-full"
              />
            </motion.a>
          ))}
        </nav>

        {/* Right Column: Call to Action */}
        <div className="flex items-center">
          <Link href="/admin/login">
            <motion.div
              whileHover={{ boxShadow: "0px 0px 15px rgba(34, 211, 238, 0.5)" }}
              whileTap={{ scale: 0.95 }}
              className="px-5 py-2 text-sm rounded-full bg-[#2563EB] text-white hover:scale-105 transition-transform cursor-pointer"
            >
              Admin
            </motion.div>
          </Link>
        </div>
      </div>
    </motion.header>
  )
}
